﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class UserGroup
    {
        public int UserGroupId { get; set; }
        public string Name { get; set; }
        public ICollection<User>? Users { get; set; }
    }

}

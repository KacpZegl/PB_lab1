﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOModels
{
    public class OrderResponseDTO
    {
        public int OrderId { get; private set; }
        public int UserId { get; private set; }
        public DateTime OrderDate { get; private set; }
        public IEnumerable<OrderPositionDTO> OrderItems { get; private set; }

        public OrderResponseDTO(int orderId, int userId, DateTime orderDate, IEnumerable<OrderPositionDTO> orderItems)
        {
            OrderId = orderId;
            UserId = userId;
            OrderDate = orderDate;
            OrderItems = orderItems ?? throw new ArgumentNullException(nameof(orderItems));
        }
    }
}

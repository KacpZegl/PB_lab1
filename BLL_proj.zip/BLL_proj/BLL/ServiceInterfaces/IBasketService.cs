﻿using BLL.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.ServiceInterfaces
{
    public interface IBasketService
    {
        Task AddProductToBasketAsync(BasketItemRequestDTO basketItem);
        Task ChangeBasketItemAmountAsync(int basketItemId, int newAmount);
        Task RemoveProductFromBasketAsync(int basketItemId);
        Task<OrderResponseDTO> CheckoutAsync(int userId);
    }
}

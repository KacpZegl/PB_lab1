﻿using BLL.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.ServiceInterfaces
{
    public interface IProductService
    {
        Task<IEnumerable<ProductResponseDTO>> GetActiveProductsAsync(string sortBy, string nameFilter, string groupFilter, int? groupIdFilter, bool includeInactive = false);
        Task AddProductAsync(ProductRequestDTO product);
        Task DeactivateOrDeleteProductAsync(int productId);
        Task ActivateProductAsync(int productId);
    }
}
